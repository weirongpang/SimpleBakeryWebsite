/**
 * 
 */
 
 
function validation()
{
	let name = document.getElementById("name").value;
	let student_id = document.getElementById("student_id").value;
	let email = document.getElementById("email").value;
	let department = document.getElementById("department").value;
	let message = document.getElementById("message").value;
	let error_message = document.getElementById("error_message");
	
	error_message.style.padding = "10px";
	
	let text;
	
	if(name.length < 5){
		text = "Please enter your correct VALID Name";
		error_message.innerHTML = text;
		return false;
	}
	
	if(student_id.length < 10){
		text = "Please enter your correct VALID Student ID";
		error_message.innerHTML = text;
		return false;
	}
	
	if(department.length < 10){
		text = "Please enter your correct Department";
		error_message.innerHTML = text;
		return false;
	}

	if(email.indexOf("@") == -1 || email.length < 6){
		text = "Please enter your correct VALID Email";
		error_message.innerHTML = text;
		return false;
	}
	if(message.length <= 20){
		text = "Please Enter More Than 20 Characters";
		error_message.innerHTML = text;
		return false;
	}
	alert("Your Message is Submitted Successfully!");
	return true;
}
